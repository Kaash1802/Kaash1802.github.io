Video Addon Template for Kodi
=============================

This is a simple video addon template for Kodi. All you need to do to get started
is to implement your parsing in comm.py to grab the video urls.

The exsiting addon structure will handle the rest.
